import os
import sys
import subprocess
import webbrowser
import time
import socket
import platform
import threading
import requests
from urllib.parse import urlparse

class FileSharingLauncherEnhanced:
    def __init__(self):
        self.system = platform.system().lower()
        self.local_ip = self.get_local_ip()
        self.flask_process = None
        self.tunnel_process = None
        self.public_url = None
        
    def get_local_ip(self):
        """获取本地IP地址"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def print_banner(self):
        """打印启动横幅"""
        banner = """
        ╔══════════════════════════════════════════════════════╗
        ║             文件分享网站一键启动工具 - 增强版         ║
        ║        File Sharing Launcher with Free Tunnel       ║
        ╚══════════════════════════════════════════════════════╝
        """
        print(banner)
    
    def check_cloudflared(self):
        """检查Cloudflared"""
        print("🔍 检查内网穿透工具...")
        
        # 检查是否已安装cloudflared
        if os.path.exists("cloudflared.exe"):
            print("✅ Cloudflared 已安装")
            return True
        
        print("❌ Cloudflared 未安装")
        return False
    
    def install_cloudflared(self):
        """安装Cloudflared"""
        print("\n📥 正在安装Cloudflared...")
        try:
            if self.system == "windows":
                # 下载Cloudflared
                download_url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
                
                print("正在下载Cloudflared...")
                try:
                    import urllib.request
                    urllib.request.urlretrieve(download_url, "cloudflared.exe")
                    print("✅ Cloudflared 下载成功")
                    return True
                except:
                    print("❌ Cloudflared 下载失败，请手动下载")
                    return False
            else:
                print("❌ 暂不支持此操作系统")
                return False
                
        except Exception as e:
            print(f"❌ 安装失败: {e}")
            return False
    
    def start_tunnel(self):
        """启动内网穿透隧道"""
        print("\n🌐 启动内网穿透隧道...")
        
        def run_tunnel():
            try:
                self.tunnel_process = subprocess.Popen([
                    "cloudflared.exe", "tunnel", "--url", "http://localhost:5000"
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
                
                # 读取隧道输出
                while True:
                    line = self.tunnel_process.stdout.readline()
                    if not line and self.tunnel_process.poll() is not None:
                        break
                    if line:
                        print(f"[隧道] {line.strip()}")
                        
                        # 解析公网URL
                        if ".trycloudflare.com" in line:
                            parts = line.strip().split()
                            for part in parts:
                                if "https://" in part and ".trycloudflare.com" in part:
                                    self.public_url = part
                                    print(f"🎉 公网访问地址: {self.public_url}")
                                    break
                    
            except Exception as e:
                print(f"隧道错误: {e}")
        
        # 在后台线程中启动隧道
        tunnel_thread = threading.Thread(target=run_tunnel, daemon=True)
        tunnel_thread.start()
        
        # 等待隧道启动
        print("⏳ 等待隧道启动...")
        for i in range(30):
            if self.public_url:
                return True
            time.sleep(1)
        
        print("⚠️  隧道启动较慢，公网地址将在稍后显示")
        return True
    
    def start_flask(self):
        """启动Flask应用"""
        print("\n🚀 启动文件分享网站...")
        try:
            # 确保必要目录存在
            os.makedirs("uploads", exist_ok=True)
            os.makedirs("templates", exist_ok=True)
            
            # 启动Flask应用
            self.flask_process = subprocess.Popen([
                sys.executable, "app.py"
            ])
            
            # 等待应用启动
            time.sleep(8)  # 增加等待时间确保应用完全启动
            
            # 检查应用是否正常启动
            for i in range(10):  # 重试机制
                try:
                    response = requests.get(f"http://localhost:5000/health", timeout=10)
                    if response.status_code == 200:
                        print("✅ 文件分享网站启动成功")
                        return True
                except:
                    if i == 9:  # 最后一次重试
                        print("❌ 文件分享网站启动失败")
                        return False
                    time.sleep(2)  # 等待2秒后重试
                    
        except Exception as e:
            print(f"❌ 启动失败: {e}")
            return False
    
    def open_browser(self):
        """打开浏览器"""
        print("\n🌐 正在打开浏览器...")
        time.sleep(2)
        
        urls = []
        if self.public_url:
            urls.append(self.public_url)
        urls.extend([
            f"http://localhost:5000",
            f"http://{self.local_ip}:5000"
        ])
        
        for url in urls:
            try:
                webbrowser.open(url)
                print(f"✅ 已打开: {url}")
                break
            except:
                continue
    
    def show_access_info(self):
        """显示访问信息"""
        print("\n" + "="*60)
        print("🎉 文件分享网站启动完成!")
        print("="*60)
        
        print(f"\n📱 访问方式:")
        print(f"   本地访问: http://localhost:5000")
        print(f"   局域网访问: http://{self.local_ip}:5000")
        
        if self.public_url:
            print(f"   🌍 公网访问: {self.public_url}")
            print(f"   ✅ 朋友可以通过此链接在任何网络访问!")
        else:
            print(f"   🔄 公网地址生成中...稍后显示")
        
        print(f"\n🔑 管理员账号:")
        print(f"   用户名: lin")
        print(f"   密  码: 201209")
        
        print(f"\n📊 管理界面:")
        print(f"   上传文件: http://{self.local_ip}:5000/admin/upload")
        print(f"   管理后台: http://{self.local_ip}:5000/admin")
        
        print(f"\n💡 提示:")
        print(f"   - 按 Ctrl+C 停止服务")
        print(f"   - 公网地址是永久免费的")
        print(f"   - 朋友访问时请分享公网链接")
        print("="*60)
    
    def cleanup(self):
        """清理进程"""
        print("\n\n🛑 正在停止服务...")
        try:
            if self.flask_process:
                self.flask_process.terminate()
            if self.tunnel_process:
                self.tunnel_process.terminate()
            print("✅ 服务已停止")
        except Exception as e:
            print(f"❌ 停止服务时出错: {e}")
    
    def run(self):
        """主运行方法"""
        self.print_banner()
        
        try:
            # 检查Python
            import sys
            version = sys.version_info
            if version.major < 3 or (version.major == 3 and version.minor < 6):
                print("❌ 需要Python 3.6或更高版本")
                input("按回车键退出...")
                return
            
            print("✅ Python环境检查通过")
            
            # 检查依赖
            try:
                import flask
                print("✅ Flask 已安装")
            except ImportError:
                print("❌ Flask 未安装，正在安装...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", "flask"])
                print("✅ Flask 安装成功")
            
            # 检查并安装内网穿透工具
            if not self.check_cloudflared():
                print("\n是否自动安装内网穿透工具? (y/n)")
                choice = input("选择: ").lower().strip()
                if choice == 'y':
                    if not self.install_cloudflared():
                        print("将继续使用本地访问模式")
                else:
                    print("将继续使用本地访问模式")
            
            # 启动Flask应用
            if not self.start_flask():
                input("按回车键退出...")
                return
            
            # 启动内网穿透
            if self.check_cloudflared():
                self.start_tunnel()
            
            # 显示访问信息
            self.show_access_info()
            
            # 打开浏览器
            self.open_browser()
            
            print("\n⏳ 服务运行中...")
            print("💡 提示: 公网地址可能稍后才显示，请耐心等待")
            input("按回车键停止服务并退出...")
            
        except KeyboardInterrupt:
            print("\n\n⏹️  用户中断")
        except Exception as e:
            print(f"\n❌ 启动过程中出错: {e}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    launcher = FileSharingLauncherEnhanced()
    launcher.run()