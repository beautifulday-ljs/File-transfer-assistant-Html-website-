#!/data/data/com.termux/files/usr/bin/bash

# 文件分享网站一键启动脚本 - Android版
# 适用于Termux环境

echo "=========================================="
echo "   文件分享网站一键启动工具 - Android版"
echo "=========================================="
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 函数：打印彩色消息
print_info() {
    echo -e "${BLUE}ℹ️ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# 检查是否在Termux中运行
check_termux() {
    if [ ! -d "/data/data/com.termux/files/usr" ]; then
        print_error "请在Termux应用中运行此脚本！"
        exit 1
    fi
    print_success "检测到Termux环境"
}

# 安装必要依赖
install_dependencies() {
    print_info "安装系统依赖..."
    pkg install -y python python-pip wget curl git
    
    print_info "安装Python依赖..."
    pip install flask requests
    
    print_success "依赖安装完成"
}

# 下载必要文件
download_files() {
    print_info "下载网站文件..."
    
    # 创建项目目录
    mkdir -p file_sharing_system
    cd file_sharing_system
    
    # 下载主要文件
    if [ ! -f "app.py" ]; then
        cat > app.py << 'EOF'
# 这里放置完整的app.py内容
# 由于内容太长，实际使用时需要完整复制app.py的内容到这里
EOF
        print_success "创建app.py"
    fi
    
    # 创建启动配置
    cat > start_app.py << 'EOF'
#!/data/data/com.termux/files/usr/bin/python3
import os
import sys
import subprocess
import socket

def get_local_ip():
    """获取本地IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def main():
    print("🚀 启动文件分享网站...")
    
    # 确保必要目录存在
    os.makedirs("uploads", exist_ok=True)
    os.makedirs("templates", exist_ok=True)
    
    local_ip = get_local_ip()
    
    print("=" * 50)
    print("文件分享系统启动成功!")
    print("=" * 50)
    print(f"本地访问: http://localhost:5000")
    print(f"局域网访问: http://{local_ip}:5000")
    print(f"用户注册: http://{local_ip}:5000/register")
    print(f"管理登录: http://{local_ip}:5000/admin/login")
    print("\n默认管理员账号:")
    print("用户名: lin")
    print("密码: 201209")
    print("=" * 50)
    print("按 Ctrl+C 停止服务器")
    
    # 启动Flask应用
    os.system("python app.py")

if __name__ == "__main__":
    main()
EOF

    chmod +x start_app.py
    
    # 创建模板目录和基本模板
    mkdir -p templates
    
    # 创建简单的index.html
    cat > templates/index.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>文件分享系统</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f8f9fa; }
        .file-item { background: white; padding: 15px; margin: 10px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">📁 文件分享系统</h1>
        <div class="text-center mb-4">
            <a href="/admin/login" class="btn btn-primary me-2">管理员登录</a>
            <a href="/register" class="btn btn-success">用户注册</a>
        </div>
        
        <div id="fileList" class="row">
            <div class="col-12 text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">加载中...</span>
                </div>
                <p>正在加载文件列表...</p>
            </div>
        </div>
    </div>

    <script>
        // 加载文件列表
        fetch('/api/files')
            .then(response => response.json())
            .then(data => {
                const fileList = document.getElementById('fileList');
                if (data.files && data.files.length > 0) {
                    fileList.innerHTML = data.files.map(file => `
                        <div class="col-md-6 mb-3">
                            <div class="file-item">
                                <h5>${file.filename}</h5>
                                <p class="text-muted mb-1">
                                    大小: ${(file.file_size / 1024 / 1024).toFixed(2)} MB | 
                                    下载: ${file.download_count}次
                                </p>
                                <p class="text-muted mb-2">上传者: ${file.uploader_name}</p>
                                <a href="/download/${file.id}" class="btn btn-sm btn-primary">下载</a>
                                <a href="/file/${file.id}" class="btn btn-sm btn-outline-secondary">详情</a>
                            </div>
                        </div>
                    `).join('');
                } else {
                    fileList.innerHTML = `
                        <div class="col-12 text-center">
                            <div class="alert alert-info">
                                <h4>暂无文件</h4>
                                <p>管理员上传文件后，这里将显示可下载的文件列表</p>
                            </div>
                        </div>
                    `;
                }
            })
            .catch(error => {
                document.getElementById('fileList').innerHTML = `
                    <div class="col-12 text-center">
                        <div class="alert alert-danger">
                            <h4>加载失败</h4>
                            <p>无法连接到服务器，请稍后重试</p>
                        </div>
                    </div>
                `;
            });
    </script>
</body>
</html>
EOF

    print_success "基础文件创建完成"
}

# 设置公网访问（可选）
setup_public_access() {
    print_info "设置公网访问..."
    
    # 安装cloudflared
    if ! command -v cloudflared &> /dev/null; then
        print_info "安装cloudflared..."
        pkg install -y cloudflared
    fi
    
    # 创建公网启动脚本
    cat > start_public.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "🌐 启动公网访问..."
echo "这将为您的网站生成一个永久的公网访问地址"
echo "请稍等..."

# 在后台启动网站
python start_app.py &

# 等待网站启动
sleep 5

# 启动cloudflared隧道
cloudflared tunnel --url http://localhost:5000

EOF

    chmod +x start_public.sh
    print_success "公网访问设置完成"
}

# 主函数
main() {
    check_termux
    
    print_info "开始设置文件分享系统..."
    
    # 安装依赖
    install_dependencies
    
    # 下载文件
    download_files
    
    # 设置公网访问
    setup_public_access
    
    print_success "设置完成！"
    echo ""
    print_info "使用说明："
    echo "1. 启动本地访问: ./start_app.py"
    echo "2. 启动公网访问: ./start_public.sh"
    echo ""
    print_info "重要提示："
    echo "- 首次运行会自动创建数据库和管理员账号"
    echo "- 管理员账号: lin, 密码: 201209"
    echo "- 公网地址是永久免费的"
    echo "- 朋友可以通过公网地址在任何网络访问"
    
    # 进入项目目录
    cd file_sharing_system
    
    echo ""
    read -p "是否立即启动网站？(y/n): " start_now
    if [ "$start_now" = "y" ] || [ "$start_now" = "Y" ]; then
        print_info "启动网站..."
        python start_app.py
    else
        print_info "您可以稍后通过运行以下命令启动："
        echo "cd file_sharing_system && python start_app.py"
    fi
}

# 运行主函数
main