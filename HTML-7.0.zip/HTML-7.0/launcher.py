#!/usr/bin/env python3
"""
文件分享网站一键启动工具
支持自动环境检查、依赖安装、内网穿透
"""

import os
import sys
import subprocess
import webbrowser
import time
import socket
import platform
from threading import Thread
import requests

class FileSharingLauncher:
    def __init__(self):
        self.system = platform.system().lower()
        self.local_ip = self.get_local_ip()
        self.flask_process = None
        self.ngrok_process = None
        self.public_url = None
        
    def get_local_ip(self):
        """获取本地IP地址"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect("8.8.8.8", 80)
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def print_banner(self):
        """打印启动横幅"""
        banner = """
        ╔══════════════════════════════════════════════╗
        ║            文件分享网站一键启动工具           ║
        ║        File Sharing One-Click Launcher       ║
        ╚══════════════════════════════════════════════╝
        """
        print(banner)
    
    def check_python(self):
        """检查Python环境"""
        print("🔍 检查Python环境...")
        try:
            version = sys.version_info
            if version.major < 3 or (version.major == 3 and version.minor < 6):
                print("❌ 需要Python 3.6或更高版本")
                return False
            print(f"✅ Python {version.major}.{version.minor}.{version.micro} - 符合要求")
            return True
        except Exception as e:
            print(f"❌ Python检查失败: {e}")
            return False
    
    def check_dependencies(self):
        """检查并安装依赖"""
        print("\n🔍 检查依赖包...")
        try:
            import flask
            print("✅ Flask 已安装")
            return True
        except ImportError:
            print("❌ Flask 未安装，正在安装...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
                print("✅ Flask 安装成功")
                return True
            except Exception as e:
                print(f"❌ 依赖安装失败: {e}")
                return False
    
    def check_ngrok(self):
        """检查ngrok"""
        print("\n🔍 检查内网穿透工具...")
        try:
            # 检查是否已安装ngrok
            result = subprocess.run(["ngrok", "--version"], capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ ngrok 已安装")
                return True
        except:
            pass
        
        print("❌ ngrok 未安装")
        return False
    
    def install_ngrok(self):
        """安装ngrok"""
        print("\n📥 正在安装ngrok...")
        try:
            if self.system == "windows":
                # Windows安装
                ngrok_url = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip"
                subprocess.run(["curl", "-o", "ngrok.zip", ngrok_url])
                subprocess.run(["tar", "-xf", "ngrok.zip"])
                os.remove("ngrok.zip")
                # 添加到PATH或当前目录
                if "ngrok.exe" not in os.listdir("."):
                    print("❌ ngrok安装失败")
                    return False
            elif self.system in ["linux", "darwin"]:
                # Linux/macOS安装
                if self.system == "linux":
                    ngrok_url = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz"
                else:
                    ngrok_url = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-darwin-amd64.zip"
                
                subprocess.run(["curl", "-o", "ngrok.tgz", ngrok_url])
                subprocess.run(["tar", "-xzf", "ngrok.tgz"])
                if self.system == "linux":
                    os.remove("ngrok.tgz")
                else:
                    os.remove("ngrok.tgz")
            
            print("✅ ngrok 安装成功")
            return True
        except Exception as e:
            print(f"❌ ngrok安装失败: {e}")
            return False
    
    def start_flask(self):
        """启动Flask应用"""
        print("\n🚀 启动文件分享网站...")
        try:
            # 确保必要目录存在
            os.makedirs("uploads", exist_ok=True)
            os.makedirs("templates", exist_ok=True)
            
            # 启动Flask应用
            self.flask_process = subprocess.Popen([
                sys.executable, "app.py"
            ])
            
            # 等待应用启动
            time.sleep(3)
            
            # 检查应用是否正常启动
            try:
                response = requests.get(f"http://localhost:5000/health", timeout=5)
                if response.status_code == 200:
                    print("✅ 文件分享网站启动成功")
                    return True
            except:
                print("❌ 文件分享网站启动失败")
                return False
                
        except Exception as e:
            print(f"❌ 启动失败: {e}")
            return False
    
    def start_ngrok(self):
        """启动ngrok内网穿透"""
        print("\n🌐 启动内网穿透...")
        try:
            ngrok_cmd = "ngrok.exe" if self.system == "windows" else "./ngrok"
            if not os.path.exists(ngrok_cmd):
                ngrok_cmd = "ngrok"  # 如果在PATH中
            
            self.ngrok_process = subprocess.Popen([
                ngrok_cmd, "http", "5000"
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            # 等待ngrok启动
            time.sleep(5)
            
            # 获取公网URL
            try:
                response = requests.get("http://localhost:4040/api/tunnels", timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    tunnels = data.get("tunnels", [])
                    for tunnel in tunnels:
                        if tunnel["proto"] == "https":
                            self.public_url = tunnel["public_url"]
                            print(f"✅ 内网穿透启动成功")
                            return True
            except:
                print("⚠️  无法获取公网URL，但ngrok可能仍在运行")
                return True
                
        except Exception as e:
            print(f"❌ 内网穿透启动失败: {e}")
            return False
    
    def open_browser(self):
        """打开浏览器"""
        print("\n🌐 正在打开浏览器...")
        time.sleep(2)
        
        urls = [
            f"http://localhost:5000",
            f"http://{self.local_ip}:5000"
        ]
        
        if self.public_url:
            urls.insert(0, self.public_url)
        
        for url in urls:
            try:
                webbrowser.open(url)
                print(f"✅ 已打开: {url}")
                break
            except:
                continue
    
    def show_access_info(self):
        """显示访问信息"""
        print("\n" + "="*60)
        print("🎉 文件分享网站启动完成!")
        print("="*60)
        
        print(f"\n📱 访问方式:")
        print(f"   本地访问: http://localhost:5000")
        print(f"   局域网访问: http://{self.local_ip}:5000")
        
        if self.public_url:
            print(f"   公网访问: {self.public_url}")
            print(f"   🌍 朋友可以通过此链接访问!")
        else:
            print(f"   🔒 公网访问: 未启用 (仅在局域网内可访问)")
        
        print(f"\n🔑 管理员账号:")
        print(f"   用户名: lin")
        print(f"   密  码: 201209")
        
        print(f"\n📊 管理界面:")
        print(f"   上传文件: http://{self.local_ip}:5000/admin/upload")
        print(f"   管理后台: http://{self.local_ip}:5000/admin")
        
        print(f"\n💡 提示:")
        print(f"   - 按 Ctrl+C 停止服务")
        print(f"   - 朋友访问时请分享公网链接")
        print("="*60)
    
    def cleanup(self):
        """清理进程"""
        print("\n\n🛑 正在停止服务...")
        try:
            if self.flask_process:
                self.flask_process.terminate()
            if self.ngrok_process:
                self.ngrok_process.terminate()
            print("✅ 服务已停止")
        except Exception as e:
            print(f"❌ 停止服务时出错: {e}")
    
    def run(self):
        """主运行方法"""
        self.print_banner()
        
        try:
            # 环境检查
            if not self.check_python():
                input("按回车键退出...")
                return
            
            if not self.check_dependencies():
                input("按回车键退出...")
                return
            
            # 询问是否启用公网访问
            print("\n🌐 是否启用公网访问（让朋友可以在不同网络访问）?")
            print("   1. 启用（推荐）")
            print("   2. 仅本地访问")
            choice = input("请选择 (1/2): ").strip()
            
            enable_public = choice == "1"
            
            if enable_public:
                if not self.check_ngrok():
                    print("\n是否自动安装ngrok? (y/n)")
                    install_choice = input("选择: ").lower().strip()
                    if install_choice == 'y':
                        if not self.install_ngrok():
                            print("将继续使用本地访问模式")
                            enable_public = False
                    else:
                        enable_public = False
            
            # 启动服务
            if not self.start_flask():
                input("按回车键退出...")
                return
            
            if enable_public:
                self.start_ngrok()
            
            # 显示访问信息
            self.show_access_info()
            
            # 打开浏览器
            self.open_browser()
            
            print("\n⏳ 服务运行中...")
            input("按回车键停止服务并退出...")
            
        except KeyboardInterrupt:
            print("\n\n⏹️  用户中断")
        except Exception as e:
            print(f"\n❌ 启动过程中出错: {e}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    launcher = FileSharingLauncher()
    launcher.run()