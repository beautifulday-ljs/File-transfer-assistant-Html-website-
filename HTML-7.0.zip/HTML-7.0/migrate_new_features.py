import sqlite3
import os
import sys
import hashlib

def migrate_new_features():
    """迁移新功能数据库结构"""
    db_path = 'files.db'
    
    print("🔧 开始新功能数据库迁移...")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 检查files表是否存在description列
        cursor.execute("PRAGMA table_info(files)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # 添加description列到files表
        if 'description' not in columns:
            cursor.execute('''
                ALTER TABLE files ADD COLUMN description TEXT
            ''')
            print("✅ 添加description列到files表")
        
        # 检查users表是否存在bio列
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # 添加bio列到users表
        if 'bio' not in columns:
            cursor.execute('''
                ALTER TABLE users ADD COLUMN bio TEXT
            ''')
            print("✅ 添加bio列到users表")
        
        # 将所有uploader角色改为user角色
        cursor.execute("UPDATE users SET role = 'user' WHERE role = 'uploader'")
        if cursor.rowcount > 0:
            print(f"✅ 已将 {cursor.rowcount} 个uploader角色转换为user角色")
        
        # 设置所有用户上传的文件都需要审核
        cursor.execute("UPDATE files SET status = 'pending' WHERE status = 'approved' AND uploader_id IN (SELECT id FROM users WHERE role = 'user')")
        if cursor.rowcount > 0:
            print(f"✅ 已将 {cursor.rowcount} 个用户文件设置为待审核状态")
        
        conn.commit()
        conn.close()
        
        print("✅ 新功能数据库迁移完成")
        return True
        
    except Exception as e:
        print(f"❌ 数据库迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("文件分享系统 - 新功能数据库迁移工具")
    print("=" * 50)
    
    if migrate_new_features():
        print("\n✅ 迁移完成！现在可以正常使用新功能了")
    else:
        print("\n❌ 迁移失败，请检查错误信息")
    
    input("\n按回车键退出...")