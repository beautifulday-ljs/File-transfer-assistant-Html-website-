from flask import Flask, request, render_template, send_file, jsonify, redirect, url_for, session
import os
import sqlite3
from datetime import datetime
import hashlib
import threading
import time
import traceback
import socket
import json
import random
from functools import lru_cache
import time as time_module

#启动指令：cloudflared tunnel --url http://localhost:5000
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['DATABASE'] = 'files.db'
app.config['SECRET_KEY'] = 'file_sharing_system_secret_key_2024'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024 * 1024  # 5GB 文件大小限制

# 权限级别
PERMISSIONS = {
    'super_super_admin': 4,  # 超高权限管理员
    'super_admin': 3,        # 超级管理员
    'admin': 2,              # 普通管理员
    'user': 1                # 普通用户（可以上传文件）
}

# 存储等待更新的客户端
waiting_clients = []
client_lock = threading.Lock()

# 缓存配置
CACHE_DURATION = 300  # 5分钟缓存
file_cache = {}
cache_timestamps = {}
cache_lock = threading.Lock()

def get_local_ip():
    """获取本地IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect("8.8.8.8", 80)
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "无法获取IP地址"

def generate_captcha():
    """生成4位数字验证码"""
    return ''.join([str(random.randint(0, 9)) for _ in range(4)])

def init_db():
    """初始化数据库"""
    try:
        conn = sqlite3.connect(app.config['DATABASE'])
        c = conn.cursor()
        
        # 文件表 - 添加description字段
        c.execute('''CREATE TABLE IF NOT EXISTS files
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      filename TEXT NOT NULL,
                      original_filename TEXT NOT NULL,
                      description TEXT, -- 文件简介
                      upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      file_size INTEGER,
                      download_count INTEGER DEFAULT 0,
                      uploader_id INTEGER,
                      status TEXT DEFAULT 'pending', -- 所有用户上传的文件都需要审核
                      reviewed_by INTEGER,
                      review_time TIMESTAMP,
                      folder_id INTEGER DEFAULT 0)''')
        
        # 用户表 - 添加bio字段
        c.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      username TEXT UNIQUE NOT NULL,
                      password TEXT NOT NULL,
                      bio TEXT, -- 用户简介
                      role TEXT NOT NULL DEFAULT 'user', -- super_super_admin, super_admin, admin, user
                      created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      created_by INTEGER,
                      is_active INTEGER DEFAULT 1,
                      last_login TIMESTAMP)''')
        
        # 文件夹表
        c.execute('''CREATE TABLE IF NOT EXISTS folders
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      name TEXT NOT NULL,
                      description TEXT,
                      created_by INTEGER NOT NULL,
                      created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      parent_id INTEGER DEFAULT 0,
                      status TEXT DEFAULT 'approved',
                      reviewed_by INTEGER,
                      review_time TIMESTAMP)''')
        
        # 文件夹操作审核表
        c.execute('''CREATE TABLE IF NOT EXISTS folder_operations
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      operation_type TEXT NOT NULL,
                      target_id INTEGER NOT NULL,
                      target_type TEXT NOT NULL,
                      data TEXT,
                      requested_by INTEGER NOT NULL,
                      requested_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      status TEXT DEFAULT 'pending',
                      reviewed_by INTEGER,
                      review_time TIMESTAMP)''')
        
        # 举报表
        c.execute('''CREATE TABLE IF NOT EXISTS reports
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      file_id INTEGER NOT NULL,
                      reporter_ip TEXT NOT NULL,
                      report_reason TEXT NOT NULL,
                      report_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      status TEXT DEFAULT 'pending',
                      reviewed_by INTEGER,
                      review_time TIMESTAMP,
                      review_result TEXT,
                      review_notes TEXT)''')
        
        # 创建索引以提高查询性能
        c.execute('CREATE INDEX IF NOT EXISTS idx_files_status ON files(status)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_files_folder ON files(folder_id)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_files_uploader ON files(uploader_id)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_folders_status ON folders(status)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_folders_parent ON folders(parent_id)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)')
        
        # 我是最NB的管理员
        c.execute("SELECT COUNT(*) FROM users WHERE username = 'lin'")
        if c.fetchone()[0] == 0:
            hashed_password = hashlib.md5('201209'.encode()).hexdigest()
            c.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                     ('lin', hashed_password, 'super_super_admin'))
        
        conn.commit()
        conn.close()
        print("✓ 数据库初始化成功")
    except Exception as e:
        print(f"✗ 数据库初始化失败: {e}")
        traceback.print_exc()

def migrate_database():
    """迁移数据库结构"""
    try:
        conn = sqlite3.connect(app.config['DATABASE'])
        cursor = conn.cursor()
        
        # 检查files表是否存在description列
        cursor.execute("PRAGMA table_info(files)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # 添加description列到files表
        if 'description' not in columns:
            cursor.execute('''
                ALTER TABLE files ADD COLUMN description TEXT
            ''')
            print("✅ 添加description列到files表")
        
        # 检查users表是否存在bio列
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # 添加bio列到users表
        if 'bio' not in columns:
            cursor.execute('''
                ALTER TABLE users ADD COLUMN bio TEXT
            ''')
            print("✅ 添加bio列到users表")
        
        # 将所有uploader角色改为user角色
        cursor.execute("UPDATE users SET role = 'user' WHERE role = 'uploader'")
        if cursor.rowcount > 0:
            print(f"✅ 已将 {cursor.rowcount} 个uploader角色转换为user角色")
        
        # 设置所有用户上传的文件都需要审核
        cursor.execute("UPDATE files SET status = 'pending' WHERE status = 'approved' AND uploader_id IN (SELECT id FROM users WHERE role = 'user')")
        if cursor.rowcount > 0:
            print(f"✅ 已将 {cursor.rowcount} 个用户文件设置为待审核状态")
        
        conn.commit()
        conn.close()
        print("✅ 数据库迁移完成")
        return True
        
    except Exception as e:
        print(f"❌ 数据库迁移失败: {e}")
        return False

def get_db():
    """获取数据库连接"""
    try:
        conn = sqlite3.connect(app.config['DATABASE'])
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"✗ 数据库连接失败: {e}")
        return None

def get_user_permission_level(role):
    """获取用户权限级别"""
    return PERMISSIONS.get(role, 0)

def check_permission(required_role):
    """检查权限装饰器"""
    def decorator(f):
        def decorated_function(*args, **kwargs):
            if not session.get('admin_logged_in'):
                return redirect(url_for('admin_login'))
            
            user_role = session.get('user_role')
            if get_user_permission_level(user_role) < get_user_permission_level(required_role):
                return "权限不足", 403
            return f(*args, **kwargs)
        decorated_function.__name__ = f.__name__
        return decorated_function
    return decorator

def clear_cache(cache_key=None):
    """清除缓存"""
    with cache_lock:
        if cache_key:
            if cache_key in file_cache:
                del file_cache[cache_key]
            if cache_key in cache_timestamps:
                del cache_timestamps[cache_key]
        else:
            file_cache.clear()
            cache_timestamps.clear()

def get_cached_data(cache_key, query_func, *args, **kwargs):
    """获取缓存数据"""
    current_time = time_module.time()
    
    # 检查缓存是否存在且未过期
    with cache_lock:
        if (cache_key in file_cache and 
            cache_key in cache_timestamps and
            current_time - cache_timestamps[cache_key] < CACHE_DURATION):
            return file_cache[cache_key]
    
    # 缓存不存在或已过期，重新查询
    data = query_func(*args, **kwargs)
    
    # 更新缓存
    with cache_lock:
        file_cache[cache_key] = data
        cache_timestamps[cache_key] = current_time
    
    return data

# 确保上传目录存在
def ensure_upload_dir():
    """确保上传目录存在"""
    try:
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'])
            print(f"✓ 创建上传目录: {app.config['UPLOAD_FOLDER']}")
    except Exception as e:
        print(f"✗ 创建上传目录失败: {e}")

# 管理员登录验证装饰器
def admin_required(f):
    """验证管理员权限的装饰器"""
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# 初始化
ensure_upload_dir()
init_db()
migrate_database()

@app.route('/')
def index():
    """主页 - 用户下载页面"""
    try:
        # 获取用户登录状态
        logged_in = session.get('admin_logged_in', False)
        username = session.get('admin_username', '')
        user_role = session.get('user_role', '')
        
        return render_template('index.html', 
                             logged_in=logged_in, 
                             username=username, 
                             user_role=user_role)
    except Exception as e:
        return f"页面加载失败: {str(e)}", 500

@app.route('/api/files')
def get_files():
    """获取文件列表API - 只显示已审核通过的文件"""
    try:
        folder_id = request.args.get('folder_id', 0, type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # 构建缓存键
        cache_key = f"files_{folder_id}_{page}_{per_page}"
        
        def query_files():
            conn = get_db()
            if conn is None:
                return {'error': '数据库连接失败'}
                
            # 计算偏移量
            offset = (page - 1) * per_page
            
            # 获取文件列表（使用索引优化查询）
            files = conn.execute('''
                SELECT f.*, u.username as uploader_name, u.bio as uploader_bio 
                FROM files f 
                LEFT JOIN users u ON f.uploader_id = u.id 
                WHERE f.status = 'approved' AND folder_id = ?
                ORDER BY upload_time DESC
                LIMIT ? OFFSET ?
            ''', (folder_id, per_page, offset)).fetchall()
            
            # 获取文件夹信息
            folder = None
            if folder_id > 0:
                folder = conn.execute('SELECT * FROM folders WHERE id = ? AND status = "approved"', (folder_id,)).fetchone()
            
            # 获取子文件夹
            subfolders = conn.execute('''
                SELECT * FROM folders 
                WHERE parent_id = ? AND status = 'approved'
                ORDER BY name
            ''', (folder_id,)).fetchall()
            
            # 获取总文件数（用于分页）
            total_files = conn.execute('''
                SELECT COUNT(*) FROM files 
                WHERE status = 'approved' AND folder_id = ?
            ''', (folder_id,)).fetchone()[0]
            
            conn.close()
            
            file_list = []
            for file in files:
                file_list.append({
                    'id': file['id'],
                    'filename': file['original_filename'],
                    'description': file['description'],
                    'upload_time': file['upload_time'],
                    'file_size': file['file_size'],
                    'download_count': file['download_count'],
                    'uploader_name': file['uploader_name'],
                    'uploader_bio': file['uploader_bio'],
                    'uploader_id': file['uploader_id']
                })
            
            folder_list = []
            for folder_item in subfolders:
                folder_list.append({
                    'id': folder_item['id'],
                    'name': folder_item['name'],
                    'description': folder_item['description']
                })
            
            current_folder = None
            if folder:
                current_folder = {
                    'id': folder['id'],
                    'name': folder['name'],
                    'description': folder['description'],
                    'parent_id': folder['parent_id']
                }
            
            return {
                'files': file_list,
                'folders': folder_list,
                'current_folder': current_folder,
                'pagination': {
                    'page': page,
                    'per_page': per_page,
                    'total': total_files,
                    'pages': (total_files + per_page - 1) // per_page
                }
            }
        
        # 使用缓存获取数据
        result = get_cached_data(cache_key, query_files)
        
        if 'error' in result:
            return jsonify(result), 500
            
        return jsonify(result)
    except Exception as e:
        print(f"获取文件列表错误: {e}")
        traceback.print_exc()
        return jsonify({'error': '服务器内部错误'}), 500

@app.route('/file/<int:file_id>')
def file_detail(file_id):
    """文件详情页面"""
    try:
        cache_key = f"file_detail_{file_id}"
        
        def query_file_detail():
            conn = get_db()
            if conn is None:
                return "数据库连接失败"
                
            file = conn.execute('''
                SELECT f.*, u.username as uploader_name, u.bio as uploader_bio 
                FROM files f 
                LEFT JOIN users u ON f.uploader_id = u.id 
                WHERE f.id = ? AND f.status = 'approved'
            ''', (file_id,)).fetchone()
            
            if file is None:
                return "文件不存在或未通过审核"
            
            conn.close()
            return file
        
        file = get_cached_data(cache_key, query_file_detail)
        
        if isinstance(file, str):  # 错误信息
            return file, 404 if "不存在" in file else 500
        
        return render_template('file_detail.html', file=file)
    except Exception as e:
        print(f"加载文件详情错误: {e}")
        return f"加载文件详情失败: {str(e)}", 500

@app.route('/user/<int:user_id>')
def user_profile(user_id):
    """用户详情页面"""
    try:
        cache_key = f"user_profile_{user_id}"
        
        def query_user_profile():
            conn = get_db()
            if conn is None:
                return "数据库连接失败"
                
            user = conn.execute('''
                SELECT u.*, 
                       COUNT(f.id) as file_count,
                       SUM(f.download_count) as total_downloads
                FROM users u 
                LEFT JOIN files f ON u.id = f.uploader_id AND f.status = 'approved'
                WHERE u.id = ? AND u.is_active = 1
                GROUP BY u.id
            ''', (user_id,)).fetchone()
            
            if user is None:
                return "用户不存在"
            
            # 获取用户上传的文件（限制数量）
            user_files = conn.execute('''
                SELECT * FROM files 
                WHERE uploader_id = ? AND status = 'approved'
                ORDER BY upload_time DESC 
                LIMIT 10
            ''', (user_id,)).fetchall()
            
            conn.close()
            return {'user': user, 'user_files': user_files}
        
        result = get_cached_data(cache_key, query_user_profile)
        
        if isinstance(result, str):  # 错误信息
            return result, 404 if "不存在" in result else 500
        
        return render_template('user_profile.html', 
                             user=result['user'], 
                             user_files=result['user_files'])
    except Exception as e:
        print(f"加载用户详情错误: {e}")
        return f"加载用户详情失败: {str(e)}", 500

@app.route('/register', methods=['GET', 'POST'])
def register():
    """用户注册"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        captcha = request.form.get('captcha')
        session_captcha = session.get('register_captcha')
        
        # 验证输入
        if not username or not password or not confirm_password or not captcha:
            return render_template('register.html', error='请填写完整信息')
        
        if password != confirm_password:
            return render_template('register.html', error='两次输入的密码不一致')
        
        if len(password) < 6:
            return render_template('register.html', error='密码长度至少6位')
        
        if captcha != session_captcha:
            return render_template('register.html', error='验证码错误')
        
        # 检查用户名是否已存在
        conn = get_db()
        if conn is None:
            return render_template('register.html', error='数据库连接失败')
            
        existing_user = conn.execute(
            'SELECT id FROM users WHERE username = ?', (username,)
        ).fetchone()
        
        if existing_user:
            return render_template('register.html', error='用户名已存在')
        
        # 创建用户
        hashed_password = hashlib.md5(password.encode()).hexdigest()
        conn.execute('''
            INSERT INTO users (username, password, role) 
            VALUES (?, ?, ?)
        ''', (username, hashed_password, 'user'))
        
        conn.commit()
        conn.close()
        
        # 清除验证码和缓存
        session.pop('register_captcha', None)
        clear_cache()
        
        return render_template('register_success.html', username=username)
    
    # GET请求 - 生成验证码
    captcha_code = generate_captcha()
    session['register_captcha'] = captcha_code
    
    return render_template('register.html', captcha=captcha_code)

@app.route('/api/captcha')
def get_captcha():
    """获取验证码（用于刷新）"""
    captcha_code = generate_captcha()
    session['register_captcha'] = captcha_code
    return jsonify({'captcha': captcha_code})

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """管理员登录页面"""
    # 如果已经登录，直接跳转到管理后台
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # 验证用户名和密码
        conn = get_db()
        if conn is None:
            return render_template('admin_login.html', error='数据库连接失败')
            
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND is_active = 1',
            (username,)
        ).fetchone()
        
        if user and user['password'] == hashlib.md5(password.encode()).hexdigest():
            # 更新最后登录时间
            conn.execute(
                'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?',
                (user['id'],)
            )
            conn.commit()
            
            session['admin_logged_in'] = True
            session['admin_username'] = username
            session['user_role'] = user['role']
            session['user_id'] = user['id']
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template('admin_login.html', error='用户名或密码错误')
    
    return render_template('admin_login.html')

@app.route('/logout')
def logout():
    """用户退出登录"""
    session.pop('admin_logged_in', None)
    session.pop('admin_username', None)
    session.pop('user_role', None)
    session.pop('user_id', None)
    session.pop('register_captcha', None)
    return redirect(url_for('logout_success'))

@app.route('/logout_success')
def logout_success():
    """退出成功页面"""
    return render_template('logout_success.html')

@app.route('/admin/profile', methods=['GET', 'POST'])
@admin_required
def admin_profile():
    """用户个人信息页面"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        if request.method == 'POST':
            # 更新用户简介
            bio = request.form.get('bio', '')
            conn.execute('''
                UPDATE users SET bio = ? WHERE id = ?
            ''', (bio, session.get('user_id')))
            conn.commit()
            clear_cache()  # 清除缓存
            
        user = conn.execute(
            'SELECT * FROM users WHERE id = ?', 
            (session.get('user_id'),)
        ).fetchone()
        
        # 获取用户统计数据
        file_stats = conn.execute('''
            SELECT 
                COUNT(*) as total_files,
                SUM(download_count) as total_downloads,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_files
            FROM files 
            WHERE uploader_id = ?
        ''', (session.get('user_id'),)).fetchone()
        
        # 获取文件夹统计
        folder_stats = conn.execute('''
            SELECT 
                COUNT(*) as total_folders,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_folders
            FROM folders 
            WHERE created_by = ?
        ''', (session.get('user_id'),)).fetchone()
        
        conn.close()
        
        return render_template('admin_profile.html', 
                             user=user,
                             file_stats=file_stats,
                             folder_stats=folder_stats,
                             username=session.get('admin_username'),
                             user_role=session.get('user_role'))
    except Exception as e:
        print(f"加载用户信息错误: {e}")
        traceback.print_exc()
        return f"加载用户信息失败: {str(e)}", 500

@app.route('/admin/upload', methods=['GET', 'POST'])
@admin_required
def admin_upload():
    """文件上传页面"""
    if request.method == 'POST':
        try:
            if 'file' not in request.files:
                return jsonify({'error': '没有选择文件'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': '没有选择文件'}), 400
            
            folder_id = request.form.get('folder_id', 0, type=int)
            description = request.form.get('description', '')  # 文件简介
            
            if file:
                # 生成唯一文件名
                original_filename = file.filename
                file_ext = os.path.splitext(original_filename)[1]
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{timestamp}_{hashlib.md5(original_filename.encode()).hexdigest()[:8]}{file_ext}"
                
                # 保存文件
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                
                # 获取文件大小
                file_size = os.path.getsize(file_path)
                
                # 根据用户角色设置文件状态
                user_role = session.get('user_role')
                if user_role == 'user':
                    status = 'pending'  # 普通用户需要审核
                else:
                    status = 'approved'  # 管理员直接通过
                
                # 保存到数据库
                conn = get_db()
                if conn is None:
                    return jsonify({'error': '数据库连接失败'}), 500
                    
                conn.execute('''
                    INSERT INTO files (filename, original_filename, description, file_size, uploader_id, status, folder_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (filename, original_filename, description, file_size, session.get('user_id'), status, folder_id))
                conn.commit()
                conn.close()
                
                # 清除缓存
                clear_cache()
                
                # 通知所有等待的客户端有新文件（仅限已审核文件）
                if status == 'approved':
                    with client_lock:
                        for client in waiting_clients:
                            client['new_file'] = True
                        waiting_clients.clear()
                
                message = '文件上传成功' if status == 'approved' else '文件上传成功，等待管理员审核'
                return jsonify({'success': True, 'message': message, 'needs_review': status == 'pending'})
        except Exception as e:
            print(f"文件上传错误: {e}")
            traceback.print_exc()
            return jsonify({'error': f'上传失败: {str(e)}'}), 500
    
    try:
        # 获取文件夹列表
        conn = get_db()
        folders = conn.execute('''
            SELECT * FROM folders 
            WHERE status = 'approved' 
            ORDER BY name
        ''').fetchall()
        conn.close()
        
        return render_template('admin_upload.html', 
                             username=session.get('admin_username'), 
                             user_role=session.get('user_role'),
                             folders=folders)
    except Exception as e:
        return f"页面加载失败: {str(e)}", 500

@app.route('/api/check_updates')
def check_updates():
    """长轮询检查更新"""
    def wait_for_update():
        with client_lock:
            client = {'new_file': False}
            waiting_clients.append(client)
        
        # 等待最多30秒
        for _ in range(30):
            if client['new_file']:
                return True
            time.sleep(1)
        
        return False
    
    try:
        if wait_for_update():
            return jsonify({'update': True})
        else:
            return jsonify({'update': False})
    except Exception as e:
        print(f"检查更新错误: {e}")
        return jsonify({'update': False, 'error': str(e)})

@app.route('/download/<int:file_id>')
def download_file(file_id):
    """文件下载"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        file = conn.execute('SELECT * FROM files WHERE id = ?', (file_id,)).fetchone()
        
        if file is None:
            return "文件不存在", 404
        
        # 只有已审核的文件可以下载
        if file['status'] != 'approved':
            return "文件未通过审核", 403
        
        # 更新下载次数
        conn.execute('UPDATE files SET download_count = download_count + 1 WHERE id = ?', (file_id,))
        conn.commit()
        conn.close()
        
        # 清除相关缓存
        clear_cache(f"files_{file['folder_id']}_1_20")
        clear_cache(f"file_detail_{file_id}")
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file['filename'])
        if not os.path.exists(file_path):
            return "文件不存在", 404
            
        return send_file(file_path, as_attachment=True, download_name=file['original_filename'])
    except Exception as e:
        print(f"文件下载错误: {e}")
        traceback.print_exc()
        return f"下载失败: {str(e)}", 500

@app.route('/preview/<int:file_id>')
def preview_file(file_id):
    """预览文件（用于审核）"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        file = conn.execute('SELECT * FROM files WHERE id = ?', (file_id,)).fetchone()
        
        if file is None:
            return "文件不存在", 404
        
        # 在审核过程中可以下载任何状态的文件
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file['filename'])
        if not os.path.exists(file_path):
            return "文件不存在", 404
            
        return send_file(file_path, as_attachment=True, download_name=file['original_filename'])
    except Exception as e:
        print(f"文件预览错误: {e}")
        traceback.print_exc()
        return f"预览失败: {str(e)}", 500

@app.route('/report/<int:file_id>', methods=['POST'])
def report_file(file_id):
    """举报文件"""
    try:
        reason = request.form.get('reason', '')
        reporter_ip = request.remote_addr
        
        if not reason:
            return jsonify({'error': '请填写举报原因'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查文件是否存在
        file = conn.execute('SELECT * FROM files WHERE id = ?', (file_id,)).fetchone()
        if not file:
            return jsonify({'error': '文件不存在'}), 404
        
        # 检查是否已经举报过（同一IP对同一文件）
        existing_report = conn.execute(
            'SELECT id FROM reports WHERE file_id = ? AND reporter_ip = ? AND status = "pending"',
            (file_id, reporter_ip)
        ).fetchone()
        
        if existing_report:
            return jsonify({'error': '您已经举报过此文件，请等待管理员处理'}), 400
        
        # 添加举报记录
        conn.execute('''
            INSERT INTO reports (file_id, reporter_ip, report_reason)
            VALUES (?, ?, ?)
        ''', (file_id, reporter_ip, reason))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': '举报成功，管理员会尽快处理'})
    except Exception as e:
        print(f"举报文件错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'举报失败: {str(e)}'}), 500

@app.route('/admin')
@admin_required
def admin_dashboard():
    """管理员后台"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        user_role = session.get('user_role')
        
        # 根据用户角色显示不同的文件（限制数量）
        if user_role == 'user':
            # 普通用户只能看到自己上传的文件
            files = conn.execute('''
                SELECT * FROM files 
                WHERE uploader_id = ?
                ORDER BY upload_time DESC
                LIMIT 50
            ''', (session.get('user_id'),)).fetchall()
        else:
            # 管理员可以看到所有文件（限制数量）
            files = conn.execute('''
                SELECT * FROM files 
                ORDER BY upload_time DESC 
                LIMIT 50
            ''').fetchall()
        
        # 获取待审核文件数量（管理员可见）
        pending_count = 0
        if user_role in ['admin', 'super_admin', 'super_super_admin']:
            pending_count = conn.execute(
                'SELECT COUNT(*) FROM files WHERE status = "pending"'
            ).fetchone()[0]
        
        # 获取待审核文件夹操作数量
        pending_operations = 0
        if user_role in ['admin', 'super_admin', 'super_super_admin']:
            pending_operations = conn.execute(
                'SELECT COUNT(*) FROM folder_operations WHERE status = "pending"'
            ).fetchone()[0]
        
        # 获取待处理举报数量
        pending_reports = 0
        if user_role in ['admin', 'super_admin', 'super_super_admin']:
            pending_reports = conn.execute(
                'SELECT COUNT(*) FROM reports WHERE status = "pending"'
            ).fetchone()[0]
        
        conn.close()
        
        return render_template('admin_dashboard.html', 
                             files=files, 
                             username=session.get('admin_username'),
                             user_role=user_role,
                             pending_count=pending_count,
                             pending_operations=pending_operations,
                             pending_reports=pending_reports)
    except Exception as e:
        print(f"管理后台加载错误: {e}")
        traceback.print_exc()
        return f"加载管理后台失败: {str(e)}", 500

@app.route('/admin/users')
@admin_required
@check_permission('admin')  # 至少需要管理员权限
def user_management():
    """用户管理页面"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        current_user_role = session.get('user_role')
        current_username = session.get('admin_username')
        
        # 根据权限过滤用户
        if current_user_role == 'super_super_admin':
            # 超高权限管理员可以看到所有用户
            users = conn.execute('''
                SELECT u.*, creator.username as created_by_name 
                FROM users u 
                LEFT JOIN users creator ON u.created_by = creator.id
                WHERE u.is_active = 1
                ORDER BY u.created_time DESC
            ''').fetchall()
        else:
            # 其他管理员不能看到超高权限管理员（除了lin自己）
            users = conn.execute('''
                SELECT u.*, creator.username as created_by_name 
                FROM users u 
                LEFT JOIN users creator ON u.created_by = creator.id
                WHERE u.is_active = 1 AND u.role != 'super_super_admin'
                ORDER BY u.created_time DESC
            ''').fetchall()
        
        conn.close()
        
        return render_template('admin_users.html', 
                             users=users, 
                             username=session.get('admin_username'),
                             user_role=session.get('user_role'))
    except Exception as e:
        print(f"用户管理页面加载错误: {e}")
        traceback.print_exc()
        return f"加载用户管理页面失败: {str(e)}", 500

@app.route('/admin/users/add', methods=['POST'])
@admin_required
def add_user():
    """添加用户"""
    try:
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        
        if not username or not password or not role:
            return jsonify({'error': '请填写完整信息'}), 400
        
        # 权限检查
        current_user_role = session.get('user_role')
        current_username = session.get('admin_username')
        
        if role == 'super_super_admin' and current_username != 'lin':
            return jsonify({'error': '只有lin可以创建超高权限管理员'}), 403
        elif role == 'super_admin' and current_user_role not in ['super_admin', 'super_super_admin']:
            return jsonify({'error': '只有超级管理员或更高权限可以创建超级管理员'}), 403
        elif role == 'admin' and current_user_role not in ['super_admin', 'super_super_admin']:
            return jsonify({'error': '只有超级管理员或更高权限可以创建普通管理员'}), 403
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查用户名是否已存在（包括已删除的用户）
        existing_user = conn.execute(
            'SELECT id FROM users WHERE username = ?', (username,)
        ).fetchone()
        
        if existing_user:
            # 如果用户存在但是已删除，可以恢复
            deleted_user = conn.execute(
                'SELECT id, is_active FROM users WHERE username = ?', (username,)
            ).fetchone()
            if deleted_user and deleted_user['is_active'] == 0:
                # 恢复已删除的用户
                hashed_password = hashlib.md5(password.encode()).hexdigest()
                conn.execute('''
                    UPDATE users SET password = ?, role = ?, is_active = 1, created_by = ?
                    WHERE username = ?
                ''', (hashed_password, role, session.get('user_id'), username))
                conn.commit()
                conn.close()
                clear_cache()  # 清除缓存
                return jsonify({'success': True, 'message': '用户恢复成功'})
            else:
                return jsonify({'error': '用户名已存在'}), 400
        
        # 添加新用户
        hashed_password = hashlib.md5(password.encode()).hexdigest()
        conn.execute('''
            INSERT INTO users (username, password, role, created_by) 
            VALUES (?, ?, ?, ?)
        ''', (username, hashed_password, role, session.get('user_id')))
        conn.commit()
        conn.close()
        
        clear_cache()  # 清除缓存
        
        return jsonify({'success': True, 'message': '用户添加成功'})
    except Exception as e:
        print(f"添加用户错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'添加失败: {str(e)}'}), 500

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
@admin_required
@check_permission('super_admin')  # 只有超级管理员及以上可以删除用户
def delete_user(user_id):
    """删除用户"""
    try:
        # 不能删除自己
        if user_id == session.get('user_id'):
            return jsonify({'error': '不能删除自己的账号'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查用户是否存在
        user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        if not user:
            return jsonify({'error': '用户不存在'}), 404
        
        current_user = conn.execute(
            'SELECT * FROM users WHERE id = ?', (session.get('user_id'),)
        ).fetchone()
        
        # 权限检查：只有lin可以删除其他超高权限管理员
        if user['role'] == 'super_super_admin':
            if current_user['username'] != 'lin':
                return jsonify({'error': '只有lin可以删除超高权限管理员'}), 403
        
        # 删除用户（软删除）
        conn.execute('UPDATE users SET is_active = 0 WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
        
        clear_cache()  # 清除缓存
        
        return jsonify({'success': True, 'message': '用户删除成功'})
    except Exception as e:
        print(f"删除用户错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'删除失败: {str(e)}'}), 500

@app.route('/admin/review')
@admin_required
@check_permission('admin')  # 至少需要管理员权限
def file_review():
    """文件审核页面"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
            
        # 获取待审核文件（限制数量）
        pending_files = conn.execute('''
            SELECT f.*, u.username as uploader_name 
            FROM files f 
            LEFT JOIN users u ON f.uploader_id = u.id 
            WHERE f.status = 'pending' 
            ORDER BY f.upload_time DESC
            LIMIT 100
        ''').fetchall()
        
        # 获取待审核文件夹操作（限制数量）
        pending_operations = conn.execute('''
            SELECT fo.*, u.username as requester_name 
            FROM folder_operations fo 
            LEFT JOIN users u ON fo.requested_by = u.id 
            WHERE fo.status = 'pending' 
            ORDER BY fo.requested_time DESC
            LIMIT 100
        ''').fetchall()
        
        # 获取待处理举报（限制数量）
        pending_reports = conn.execute('''
            SELECT r.*, f.original_filename, f.filename, f.upload_time, f.file_size, 
                   u.username as uploader_name
            FROM reports r 
            LEFT JOIN files f ON r.file_id = f.id 
            LEFT JOIN users u ON f.uploader_id = u.id 
            WHERE r.status = 'pending' 
            ORDER BY r.report_time DESC
            LIMIT 100
        ''').fetchall()
        
        conn.close()
        
        return render_template('admin_review.html', 
                             pending_files=pending_files, 
                             pending_operations=pending_operations,
                             pending_reports=pending_reports,
                             username=session.get('admin_username'),
                             user_role=session.get('user_role'))
    except Exception as e:
        print(f"文件审核页面加载错误: {e}")
        traceback.print_exc()
        return f"加载文件审核页面失败: {str(e)}", 500

@app.route('/admin/review/<int:file_id>', methods=['POST'])
@admin_required
@check_permission('admin')  # 至少需要管理员权限
def review_file(file_id):
    """审核文件"""
    try:
        action = request.form.get('action')  # approve 或 reject
        
        if action not in ['approve', 'reject']:
            return jsonify({'error': '无效的操作'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查文件是否存在且待审核
        file = conn.execute(
            'SELECT * FROM files WHERE id = ? AND status = "pending"', (file_id,)
        ).fetchone()
        
        if not file:
            return jsonify({'error': '文件不存在或已审核'}), 404
        
        # 更新文件状态
        status = 'approved' if action == 'approve' else 'rejected'
        conn.execute('''
            UPDATE files 
            SET status = ?, reviewed_by = ?, review_time = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (status, session.get('user_id'), file_id))
        
        # 清除缓存
        clear_cache()
        
        # 如果审核通过，通知客户端
        if action == 'approve':
            with client_lock:
                for client in waiting_clients:
                    client['new_file'] = True
                waiting_clients.clear()
        
        conn.commit()
        conn.close()
        
        action_text = '通过' if action == 'approve' else '拒绝'
        return jsonify({'success': True, 'message': f'文件审核{action_text}'})
    except Exception as e:
        print(f"文件审核错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'审核失败: {str(e)}'}), 500

@app.route('/admin/review_operation/<int:operation_id>', methods=['POST'])
@admin_required
@check_permission('admin')  # 至少需要管理员权限
def review_operation(operation_id):
    """审核文件夹操作"""
    try:
        action = request.form.get('action')  # approve 或 reject
        
        if action not in ['approve', 'reject']:
            return jsonify({'error': '无效的操作'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查操作是否存在且待审核
        operation = conn.execute(
            'SELECT * FROM folder_operations WHERE id = ? AND status = "pending"', (operation_id,)
        ).fetchone()
        
        if not operation:
            return jsonify({'error': '操作不存在或已审核'}), 404
        
        status = 'approved' if action == 'approve' else 'rejected'
        
        if action == 'approve':
            # 执行操作
            data = json.loads(operation['data']) if operation['data'] else {}
            
            if operation['operation_type'] == 'create_folder':
                # 创建文件夹
                conn.execute('''
                    UPDATE folders 
                    SET status = 'approved', reviewed_by = ?, review_time = CURRENT_TIMESTAMP 
                    WHERE id = ?
                ''', (session.get('user_id'), operation['target_id']))
            
            elif operation['operation_type'] == 'move_file':
                # 移动文件
                conn.execute('''
                    UPDATE files 
                    SET folder_id = ? 
                    WHERE id = ?
                ''', (data.get('target_folder_id'), operation['target_id']))
            
            elif operation['operation_type'] == 'delete_folder':
                # 删除文件夹（软删除）
                conn.execute('''
                    UPDATE folders 
                    SET status = 'rejected' 
                    WHERE id = ?
                ''', (operation['target_id'],))
        
        # 更新操作状态
        conn.execute('''
            UPDATE folder_operations 
            SET status = ?, reviewed_by = ?, review_time = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (status, session.get('user_id'), operation_id))
        
        conn.commit()
        conn.close()
        
        # 清除缓存
        clear_cache()
        
        action_text = '通过' if action == 'approve' else '拒绝'
        return jsonify({'success': True, 'message': f'操作审核{action_text}'})
    except Exception as e:
        print(f"操作审核错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'审核失败: {str(e)}'}), 500

@app.route('/admin/review_report/<int:report_id>', methods=['POST'])
@admin_required
@check_permission('admin')  # 至少需要管理员权限
def review_report(report_id):
    """审核举报"""
    try:
        action = request.form.get('action')  # approve (保留) 或 reject (下架)
        notes = request.form.get('notes', '')
        
        if action not in ['approve', 'reject']:
            return jsonify({'error': '无效的操作'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查举报是否存在且待处理
        report = conn.execute(
            'SELECT * FROM reports WHERE id = ? AND status = "pending"', (report_id,)
        ).fetchone()
        
        if not report:
            return jsonify({'error': '举报不存在或已处理'}), 404
        
        # 更新举报状态
        review_result = 'approved' if action == 'approve' else 'rejected'
        conn.execute('''
            UPDATE reports 
            SET status = 'reviewed', reviewed_by = ?, review_time = CURRENT_TIMESTAMP,
                review_result = ?, review_notes = ?
            WHERE id = ?
        ''', (session.get('user_id'), review_result, notes, report_id))
        
        # 如果举报被批准（文件违规），则下架文件
        if action == 'reject':
            conn.execute('''
                UPDATE files 
                SET status = 'rejected', reviewed_by = ?, review_time = CURRENT_TIMESTAMP 
                WHERE id = ?
            ''', (session.get('user_id'), report['file_id']))
        
        conn.commit()
        conn.close()
        
        # 清除缓存
        clear_cache()
        
        action_text = '保留文件' if action == 'approve' else '下架文件'
        return jsonify({'success': True, 'message': f'举报处理完成：{action_text}'})
    except Exception as e:
        print(f"举报审核错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'审核失败: {str(e)}'}), 500

@app.route('/admin/folders')
@admin_required
def folder_management():
    """文件夹管理页面"""
    try:
        conn = get_db()
        if conn is None:
            return "数据库连接失败", 500
        
        # 获取所有已审核的文件夹
        folders = conn.execute('''
            SELECT f.*, u.username as creator_name 
            FROM folders f 
            LEFT JOIN users u ON f.created_by = u.id 
            WHERE f.status = 'approved' 
            ORDER BY f.name
        ''').fetchall()
        
        # 获取根目录文件（限制数量）
        root_files = conn.execute('''
            SELECT * FROM files 
            WHERE folder_id = 0 AND status = 'approved'
            LIMIT 50
        ''').fetchall()
        
        conn.close()
        
        return render_template('admin_folders.html', 
                             folders=folders,
                             root_files=root_files,
                             username=session.get('admin_username'),
                             user_role=session.get('user_role'))
    except Exception as e:
        print(f"文件夹管理页面加载错误: {e}")
        traceback.print_exc()
        return f"加载文件夹管理页面失败: {str(e)}", 500

@app.route('/admin/folders/create', methods=['POST'])
@admin_required
def create_folder():
    """创建文件夹"""
    try:
        name = request.form.get('name')
        description = request.form.get('description', '')
        parent_id = request.form.get('parent_id', 0, type=int)
        
        if not name:
            return jsonify({'error': '文件夹名称不能为空'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        user_role = session.get('user_role')
        user_id = session.get('user_id')
        
        if user_role == 'user':
            # 普通用户需要审核
            status = 'pending'
            # 记录操作
            conn.execute('''
                INSERT INTO folder_operations (operation_type, target_type, data, requested_by)
                VALUES (?, ?, ?, ?)
            ''', ('create_folder', 'folder', json.dumps({
                'name': name,
                'description': description,
                'parent_id': parent_id
            }), user_id))
            
            # 获取操作ID
            operation_id = conn.lastrowid
            
            # 创建文件夹（待审核状态）
            conn.execute('''
                INSERT INTO folders (name, description, created_by, parent_id, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (name, description, user_id, parent_id, status))
            
            folder_id = conn.lastrowid
            
            # 更新操作的目标ID
            conn.execute('''
                UPDATE folder_operations SET target_id = ? WHERE id = ?
            ''', (folder_id, operation_id))
            
            conn.commit()
            conn.close()
            
            return jsonify({
                'success': True, 
                'message': '文件夹创建请求已提交，等待管理员审核',
                'needs_review': True
            })
        else:
            # 管理员直接创建
            status = 'approved'
            conn.execute('''
                INSERT INTO folders (name, description, created_by, parent_id, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (name, description, user_id, parent_id, status))
            
            conn.commit()
            conn.close()
            
            # 清除缓存
            clear_cache()
            
            return jsonify({
                'success': True, 
                'message': '文件夹创建成功',
                'needs_review': False
            })
            
    except Exception as e:
        print(f"创建文件夹错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'创建失败: {str(e)}'}), 500

@app.route('/admin/folders/delete', methods=['POST'])
@admin_required
def delete_folder():
    """删除文件夹"""
    try:
        folder_id = request.form.get('folder_id', type=int)
        
        if not folder_id:
            return jsonify({'error': '文件夹ID不能为空'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查文件夹是否存在
        folder = conn.execute('SELECT * FROM folders WHERE id = ?', (folder_id,)).fetchone()
        if not folder:
            return jsonify({'error': '文件夹不存在'}), 404
        
        user_role = session.get('user_role')
        user_id = session.get('user_id')
        
        # 权限检查：普通用户不能删除文件夹
        if user_role == 'user':
            return jsonify({'error': '普通用户无权删除文件夹'}), 403
        
        # 检查文件夹是否为空
        folder_files = conn.execute('SELECT COUNT(*) FROM files WHERE folder_id = ?', (folder_id,)).fetchone()[0]
        subfolders = conn.execute('SELECT COUNT(*) FROM folders WHERE parent_id = ?', (folder_id,)).fetchone()[0]
        
        if folder_files > 0 or subfolders > 0:
            return jsonify({'error': '文件夹不为空，无法删除'}), 400
        
        if user_role == 'user':
            # 普通用户需要审核
            conn.execute('''
                INSERT INTO folder_operations (operation_type, target_id, target_type, requested_by)
                VALUES (?, ?, ?, ?)
            ''', ('delete_folder', folder_id, 'folder', user_id))
            
            conn.commit()
            conn.close()
            
            return jsonify({
                'success': True, 
                'message': '文件夹删除请求已提交，等待管理员审核',
                'needs_review': True
            })
        else:
            # 管理员直接删除
            conn.execute('DELETE FROM folders WHERE id = ?', (folder_id,))
            
            conn.commit()
            conn.close()
            
            # 清除缓存
            clear_cache()
            
            return jsonify({
                'success': True, 
                'message': '文件夹删除成功',
                'needs_review': False
            })
            
    except Exception as e:
        print(f"删除文件夹错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'删除失败: {str(e)}'}), 500

@app.route('/admin/folders/move_file', methods=['POST'])
@admin_required
def move_file():
    """移动文件到文件夹"""
    try:
        file_id = request.form.get('file_id', type=int)
        folder_id = request.form.get('folder_id', type=int)
        
        if not file_id:
            return jsonify({'error': '文件ID不能为空'}), 400
        
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
        
        # 检查文件是否存在
        file = conn.execute('SELECT * FROM files WHERE id = ?', (file_id,)).fetchone()
        if not file:
            return jsonify({'error': '文件不存在'}), 404
        
        user_role = session.get('user_role')
        user_id = session.get('user_id')
        
        if user_role == 'user':
            # 普通用户需要审核
            conn.execute('''
                INSERT INTO folder_operations (operation_type, target_id, target_type, data, requested_by)
                VALUES (?, ?, ?, ?, ?)
            ''', ('move_file', file_id, 'file', json.dumps({
                'target_folder_id': folder_id,
                'current_folder_id': file['folder_id']
            }), user_id))
            
            conn.commit()
            conn.close()
            
            return jsonify({
                'success': True, 
                'message': '文件移动请求已提交，等待管理员审核',
                'needs_review': True
            })
        else:
            # 管理员直接移动
            conn.execute('''
                UPDATE files SET folder_id = ? WHERE id = ?
            ''', (folder_id, file_id))
            
            conn.commit()
            conn.close()
            
            # 清除缓存
            clear_cache()
            
            return jsonify({
                'success': True, 
                'message': '文件移动成功',
                'needs_review': False
            })
            
    except Exception as e:
        print(f"移动文件错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'移动失败: {str(e)}'}), 500

@app.route('/admin/delete/<int:file_id>', methods=['POST'])
@admin_required
def delete_file(file_id):
    """删除文件"""
    try:
        conn = get_db()
        if conn is None:
            return jsonify({'error': '数据库连接失败'}), 500
            
        file = conn.execute('SELECT * FROM files WHERE id = ?', (file_id,)).fetchone()
        
        if file is None:
            return jsonify({'error': '文件不存在'}), 404
        
        user_role = session.get('user_role')
        user_id = session.get('user_id')
        
        # 权限检查：普通用户只能删除自己上传的文件，且需要审核
        if user_role == 'user':
            if file['uploader_id'] != user_id:
                return jsonify({'error': '只能删除自己上传的文件'}), 403
            
            # 普通用户删除文件需要审核
            conn.execute('''
                INSERT INTO folder_operations (operation_type, target_id, target_type, requested_by)
                VALUES (?, ?, ?, ?)
            ''', ('delete_file', file_id, 'file', user_id))
            
            conn.commit()
            conn.close()
            
            return jsonify({
                'success': True, 
                'message': '文件删除请求已提交，等待管理员审核',
                'needs_review': True
            })
        else:
            # 管理员可以直接删除文件
            # 删除物理文件
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file['filename'])
            if os.path.exists(file_path):
                os.remove(file_path)
            
            # 删除数据库记录
            conn.execute('DELETE FROM files WHERE id = ?', (file_id,))
            conn.commit()
            conn.close()
            
            # 清除缓存
            clear_cache()
            
            return jsonify({'success': True, 'message': '文件删除成功'})
    except Exception as e:
        print(f"文件删除错误: {e}")
        traceback.print_exc()
        return jsonify({'error': f'删除失败: {str(e)}'}), 500

@app.route('/health')
def health_check():
    """健康检查"""
    return jsonify({
        'status': 'healthy', 
        'timestamp': datetime.now().isoformat(),
        'upload_folder': os.path.exists(app.config['UPLOAD_FOLDER']),
        'database': os.path.exists(app.config['DATABASE']),
        'cache_size': len(file_cache)
    })

@app.route('/api/clear_cache')
@admin_required
def clear_cache_endpoint():
    """清除缓存端点（管理员专用）"""
    clear_cache()
    return jsonify({'success': True, 'message': '缓存已清除'})

@app.errorhandler(404)
def not_found(error):
    return "页面不存在", 404

@app.errorhandler(500)
def internal_error(error):
    return "服务器内部错误", 500

if __name__ == '__main__':
    local_ip = get_local_ip()
    
    print("=" * 60)
    print("文件分享系统启动中...")
    print("=" * 60)
    
    # 检查必要目录和文件
    ensure_upload_dir()
    init_db()
    migrate_database()
    
    print(f"上传目录: {os.path.abspath(app.config['UPLOAD_FOLDER'])}")
    print(f"数据库文件: {os.path.abspath(app.config['DATABASE'])}")
    print(f"模板目录: {os.path.abspath('templates')}")
    
    # 检查模板文件是否存在
    template_files = ['index.html', 'admin_login.html', 'admin_upload.html', 'admin_dashboard.html', 
                     'admin_users.html', 'admin_review.html', 'admin_profile.html', 'logout_success.html', 
                     'admin_folders.html', 'register.html', 'register_success.html', 'file_detail.html', 
                     'user_profile.html']
    for template in template_files:
        template_path = os.path.join('templates', template)
        if os.path.exists(template_path):
            print(f"✓ 模板文件 {template} 存在")
        else:
            print(f"✗ 模板文件 {template} 不存在 - 请创建此文件")
    
    print("\n" + "=" * 60)
    print("系统启动成功!")
    print("=" * 60)
    print(f"用户下载页面 (本地): http://localhost:5000")
    print(f"用户下载页面 (网络): http://{local_ip}:5000")
    print(f"用户注册页面: http://{local_ip}:5000/register")
    print(f"管理员登录页面: http://{local_ip}:5000/admin/login")
    print(f"管理员上传页面: http://{local_ip}:5000/admin/upload")
    print(f"管理员后台: http://{local_ip}:5000/admin")
    print(f"健康检查: http://{local_ip}:5000/health")
    print("\n默认管理员账号: lin")
    print("默认管理员密码: 201209")
    print("\n按 Ctrl+C 停止服务器")
    print("=" * 60)
    
    try:
        app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
    except Exception as e:
        print(f"服务器启动失败: {e}")
        traceback.print_exc()