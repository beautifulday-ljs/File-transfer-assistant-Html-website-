import sqlite3
import os
import sys

def migrate_database():
    """迁移数据库结构"""
    db_path = 'files.db'
    
    if not os.path.exists(db_path):
        print("❌ 数据库文件不存在，将自动创建")
        return True
    
    print("🔧 开始数据库迁移...")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 检查users表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cursor.fetchone():
            print("📝 创建users表...")
            cursor.execute('''
                CREATE TABLE users
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE NOT NULL,
                 password TEXT NOT NULL,
                 role TEXT NOT NULL,
                 created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 created_by INTEGER,
                 is_active INTEGER DEFAULT 1,
                 last_login TIMESTAMP)
            ''')
            
            # 插入默认管理员账号 - 确保lin是超级管理员
            import hashlib
            hashed_password = hashlib.md5('201209'.encode()).hexdigest()
            cursor.execute('''
                INSERT INTO users (username, password, role) 
                VALUES (?, ?, ?)
            ''', ('lin', hashed_password, 'super_super_admin'))
            
            print("✅ users表创建成功，lin账号设置为超高权限管理员")
        else:
            # 添加last_login字段
            cursor.execute("PRAGMA table_info(users)")
            columns = [column[1] for column in cursor.fetchall()]
            if 'last_login' not in columns:
                cursor.execute('ALTER TABLE users ADD COLUMN last_login TIMESTAMP')
                print("✅ 添加last_login列到users表")
            
            # 确保lin账号存在且是super_super_admin
            cursor.execute("SELECT * FROM users WHERE username = 'lin'")
            lin_user = cursor.fetchone()
            if not lin_user:
                # 插入lin账号
                import hashlib
                hashed_password = hashlib.md5('201209'.encode()).hexdigest()
                cursor.execute('''
                    INSERT INTO users (username, password, role) 
                    VALUES (?, ?, ?)
                ''', ('lin', hashed_password, 'super_super_admin'))
                print("✅ 添加lin超高权限管理员账号")
            else:
                # 确保lin是super_super_admin
                cursor.execute("UPDATE users SET role = 'super_super_admin' WHERE username = 'lin'")
                print("✅ 确保lin账号为超高权限管理员")
        
        # 创建folders表
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='folders'")
        if not cursor.fetchone():
            print("📝 创建folders表...")
            cursor.execute('''
                CREATE TABLE folders
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 description TEXT,
                 created_by INTEGER NOT NULL,
                 created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 parent_id INTEGER DEFAULT 0,
                 status TEXT DEFAULT 'approved', -- pending, approved, rejected
                 reviewed_by INTEGER,
                 review_time TIMESTAMP,
                 FOREIGN KEY (created_by) REFERENCES users (id),
                 FOREIGN KEY (reviewed_by) REFERENCES users (id))
            ''')
            print("✅ folders表创建成功")
        
        # 在files表中添加folder_id字段
        cursor.execute("PRAGMA table_info(files)")
        columns = [column[1] for column in cursor.fetchall()]
        if 'folder_id' not in columns:
            cursor.execute('ALTER TABLE files ADD COLUMN folder_id INTEGER DEFAULT 0')
            print("✅ 添加folder_id列到files表")
        
        # 创建folder_operations表用于记录文件夹操作审核
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='folder_operations'")
        if not cursor.fetchone():
            print("📝 创建folder_operations表...")
            cursor.execute('''
                CREATE TABLE folder_operations
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 operation_type TEXT NOT NULL, -- create_folder, move_file, delete_folder
                 target_id INTEGER NOT NULL, -- folder_id or file_id
                 target_type TEXT NOT NULL, -- folder or file
                 data TEXT, -- JSON data for the operation
                 requested_by INTEGER NOT NULL,
                 requested_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 status TEXT DEFAULT 'pending', -- pending, approved, rejected
                 reviewed_by INTEGER,
                 review_time TIMESTAMP,
                 FOREIGN KEY (requested_by) REFERENCES users (id),
                 FOREIGN KEY (reviewed_by) REFERENCES users (id))
            ''')
            print("✅ folder_operations表创建成功")
        
        # 创建举报表
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'")
        if not cursor.fetchone():
            print("📝 创建reports表...")
            cursor.execute('''
                CREATE TABLE reports
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 file_id INTEGER NOT NULL,
                 reporter_ip TEXT NOT NULL,
                 report_reason TEXT NOT NULL,
                 report_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 status TEXT DEFAULT 'pending', -- pending, reviewed
                 reviewed_by INTEGER,
                 review_time TIMESTAMP,
                 review_result TEXT, -- approved (保留), rejected (下架)
                 review_notes TEXT,
                 FOREIGN KEY (file_id) REFERENCES files (id),
                 FOREIGN KEY (reviewed_by) REFERENCES users (id))
            ''')
            print("✅ reports表创建成功")
        
        # 创建用户申请表 - 新增
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='user_requests'")
        if not cursor.fetchone():
            print("📝 创建user_requests表...")
            cursor.execute('''
                CREATE TABLE user_requests
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT NOT NULL,
                 password TEXT NOT NULL,
                 request_reason TEXT NOT NULL,
                 evidence_filename TEXT,
                 request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 status TEXT DEFAULT 'pending',
                 reviewed_by INTEGER,
                 review_time TIMESTAMP,
                 review_notes TEXT)
            ''')
            print("✅ user_requests表创建成功")
        
        conn.commit()
        conn.close()
        
        print("✅ 数据库迁移完成")
        return True
        
    except Exception as e:
        print(f"❌ 数据库迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("文件分享系统 - 数据库迁移工具")
    print("=" * 50)
    
    if migrate_database():
        print("\n✅ 迁移完成！现在可以正常启动系统了")
    else:
        print("\n❌ 迁移失败，请检查错误信息")
    
    input("\n按回车键退出...")